package db;

public class Config {
	public static final String db_driver = "com.mysql.jdbc.Driver";
	public static final String db_url = "URL";
	public static final String db_user = "USER";
	public static final String db_pass = "PASS";
}

