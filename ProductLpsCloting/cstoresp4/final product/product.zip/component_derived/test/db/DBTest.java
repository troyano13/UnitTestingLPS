package db;

import static org.junit.Assert.assertNotNull;
import org.junit.Test;

public class DBTest {

    @Test
    public void testGetConexion() {
       // assertNotNull(DB.getConexion());
    }
}
