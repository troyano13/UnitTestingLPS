INSERT INTO `product` (`id`, `name`, `description`, `price`, `img`) VALUES
(1, 'Navy Slim Fit Suit Center Vent', 'This notch lapel is the most widely used and most versatile.\r\nIt is accompanied with one bosom chest pocket and two flap pockets.\r\nIt features a centre vent and no pleat pants made of the super rayon, fabric.', 100, 'https://www.mensitaly.com/images/Mens-Navy-Slim-Fit-Suit-22079.jpg'),
(2, 'Bellagio Tuxedo Gold 3PC Suit ', 'test', 100, 'https://www.mensitaly.com/images/Mens-Gold-Color-Vest-Suit-34019.jpg'),
(3, 'Burgundy ~ Maroon ~ Wine Color Two Button Notch Party Suit', 'Burgundy Two Button Notch Party Suit & Tuxedo & Blazer w/ Black Lapel-100% Light Weight Polyester - very durable and easy to clean, black acetate inside body lining.\r\nNon-Adjustable Exact Waist Size Black Trousers are Paired Six Inches lower than Jacket.', 100, 'https://www.mensitaly.com/images/Two-Button-Burgundy-Color-Tuxedo-12943.jpg'),
(4, 'Lynda Couture Promotional Ladies Suits', 'test', 100, 'https://www.mensitaly.com/images/Lynda-Couture-Black-Ladies-Suits-18614.jpg'),
(5, 'Fashion Royal Blue Slim Fit Elbow Patches', 'test', 100, 'https://www.mensitaly.com/images/Royal-Blue-Slim-Fit-Blazer-37497.jpg');

/*B-lline*/